﻿//ICA8 For Loops
//Remar Gabriel Bacadon
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace ICA8_For_Loops
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string sTitle = "ICA8 - For Loops - Remar Gabriel Espaldon Bacadon";
            string sShapeSize = "Enter the shape size: ";
            string sShape = "Line";
            string sKey;

            int iShapeSize = 0;

            char cKey;
            bool bShapeSize = true;

            for (int iLoopEverything = 0; iLoopEverything < 3; iLoopEverything++) {
                Console.CursorLeft = (Console.WindowWidth - sTitle.Length) / 2;
                Console.WriteLine(sTitle);
                for (int iLoopValidShapeSize = 0; iLoopValidShapeSize < 3; iLoopValidShapeSize++) {
                    Console.Write(sShapeSize);
                    bShapeSize = int.TryParse(Console.ReadLine(), out iShapeSize);
                    if (iShapeSize == 0 && bShapeSize == false)
                    {
                        Console.WriteLine("You have entered an invalid number.");
                        sShapeSize = "Enter the shape size as a whole number: ";
                        iLoopValidShapeSize--;
                    }
                    if (iShapeSize < 5 && bShapeSize == true)
                    {
                        Console.WriteLine("The shape size is too low");
                        sShapeSize = "Enter a shape size above or equal to 5: ";
                        iLoopValidShapeSize--;
                    }
                    if (iShapeSize > 25)
                    {
                        Console.WriteLine("The shape size is too large");
                        sShapeSize = "Enter a shape size below or equal to 25: ";
                        iLoopValidShapeSize--;
                    }
                    if (iShapeSize >= 5 && iShapeSize <= 25)
                    {
                        for (int iLoopValidShape = 0; iLoopValidShape < 3; iLoopValidShape++)
                        {
                            Console.WriteLine("Enter desired shape: 'line', 'square', or 'triangle': ");
                            sShape = Console.ReadLine();
                            sShape = sShape.ToLower();
                            switch (sShape)
                            {
                                case "line":
                                    for (int i4 = 0; i4 < iShapeSize; i4++)
                                    {
                                        for (int i5 = 0; i5 < i4; i5++)
                                        {
                                            Console.Write("  ");
                                        }
                                        Console.WriteLine("* ");
                                    }
                                    iLoopValidShape = 3;
                                    break;
                                case "square":
                                    for (int i4 = 0; i4 < iShapeSize; i4++)
                                    {
                                        for (int i5 = 0; i5 < iShapeSize; i5++)
                                        {
                                            Console.Write("* ");
                                        }
                                        Console.WriteLine(" ");
                                    }
                                    iLoopValidShape = 3;
                                    break;
                                case "triangle":
                                    for (int i4 = 0; i4 < iShapeSize; i4++)
                                    {
                                        for (int i5 = 0; i5 < (i4+1); i5++)
                                        {
                                            Console.Write("* ");
                                        }
                                        Console.WriteLine(" ");
                                    }
                                    iLoopValidShape = 3;
                                    break;
                                default:
                                    Console.WriteLine("You have entered an invalid shape");
                                    iLoopValidShape--;
                                    break;
                            }
                            
                        }
                        Console.WriteLine("Run program again? (y/n)");
                        for (int iLoopRunProgramAgain = 0; iLoopRunProgramAgain < 3; iLoopRunProgramAgain++)
                        {
                            cKey = Console.ReadKey(true).KeyChar;
                            sKey = cKey.ToString();
                            sKey = sKey.ToLower();
                            Console.WriteLine(cKey);
                            if (sKey == "n")
                            {
                                iLoopEverything = 3;
                                iLoopValidShapeSize = 3;
                                iLoopRunProgramAgain = 3;
                            }
                            if (sKey == "y")
                            {
                                Console.Clear();
                                sShapeSize = "Enter the shape size: ";
                                iLoopEverything--;
                                iLoopValidShapeSize = 3;
                                iLoopRunProgramAgain = 3;
                            }
                        }
                    }
                }
            }
        }
    }
}
