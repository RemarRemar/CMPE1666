﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using GDIDrawer;
using System.Drawing;
namespace Lab_3___Methods
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double dX = 0, dA, dB, dC, dXLow, dXHigh, dY;

            CDrawer Canvas = new CDrawer(960, 1080, false);

            bool bKeepGoing = true;

            Title("Lab 3 methods");
            DrawBackground(Canvas);
            do
            {

                GetCoefficients(out dA, out dB, out dC);
                GetRange(out dXLow, out dXHigh);// actually domain
                DrawGraph(dA, dB, dC, dXLow, dXHigh, Canvas);
                YesNo(out bKeepGoing, "\nRun again? yes or no: ");
                Canvas.Clear();
            } while (bKeepGoing);
        }

        static private void DrawGraph(double dA, double dB, double dC, double dXLow, double dXHigh, CDrawer Canvas)
        {
            bool bDrawNo = false;
            bool bDrawDone = false;

            dXLow = (dXLow * 50) + 480;
            dXHigh = (dXHigh * 50) + 480;
            double dX = dXLow, dX1 = dXLow, dX2, dY, dY2;

            do
            {
                dX1 = dX1 - 480;
                Quadratic(dA, dB, dC, dX1, out dY);
                dY = 540 - dY;

                dX2 = dX1 + 1;
                Quadratic(dA, dB, dC, dX2, out dY2);
                dY2 = 540 - dY2;

                if ((dX + 1) < dXHigh)
                {
                    dX1 = dX;
                    dX2 = dX1 + 1;
                    Canvas.AddLine((int)dX1, (int)dY, (int)dX2, (int)dY2, Color.Blue);
                    dX++;
                    dX1 = dX;

                }
                if ((dX + 1) >= dXHigh)
                {
                    bDrawDone = true;
                }
                Canvas.Render();
                if (bDrawDone == true)
                {
                    bDrawNo = bDrawDone;
                }
            } while (bDrawNo == false);

        }
        static private void YesNo(out bool bVar, in string sMessage)
        {
            bool bYesnt = true, bOut = true;
            do
            {
                Console.Write(sMessage);
                string sYesnt = Console.ReadLine();
                sYesnt = sYesnt.ToLower();
                switch (sYesnt)
                {
                    case "yes":
                        bYesnt = true;
                        bOut = true;
                        break;
                    case "no":
                        bYesnt = false;
                        bOut = true;
                        break;
                    default:
                        bOut = false;
                        break;
                }
            } while (!bOut);
            bVar = bYesnt;
        }
        static private void GetCoefficients(out double dA, out double dB, out double dC)
        {
            //int a, b, c;

            GetValue(out dA, "Enter a value for a: ");
            GetValue(out dB, "Enter a value for b: ");
            GetValue(out dC, "Enter a value for c: ");

        }
        static private void GetRange(out double dXLow, out double dXHigh)
        {
            GetValue(out dXLow, "Enter the lower limit: ");
            GetValue(out dXHigh, "Enter the higher limit: ", dXLow);
        }
        static private void Quadratic(double dA, double dB, double dC, double dX, out double dFofX)
        {
            dX *= 0.02;
            dFofX = ((dA * Math.Pow(dX, 2)) + (dB * dX) + dC) * 50;
        }
        static private void GetValue(out double dOut, string sIn)
        {
            dOut = 0;
            bool bDouble = false;
            bool bNaur = false;
            while (bNaur == false)
            {
                Console.Write(sIn);
                bDouble = double.TryParse(Console.ReadLine(), out dOut);
                if (bDouble == true)
                {
                    bNaur = bDouble;
                }
                if (bDouble != true)
                {
                    Console.WriteLine("An invalid number was entered. Please try again.");
                }

            }
        }
        static private void GetValue(out double dOut, string sIn, double dMin)
        {
            dOut = 0;
            bool bDouble = false;
            bool bNaur = false;
            while (bNaur == false)
            {
                Console.Write(sIn);
                bDouble = double.TryParse(Console.ReadLine(), out dOut);
                if (bDouble == true && dOut > dMin)
                {
                    bNaur = bDouble;
                }
                if (bDouble == true && dOut < dMin)
                {
                    Console.WriteLine("The value entered is below the minimum accepted.");
                }
                if (bDouble != true)
                {
                    Console.WriteLine("An invalid number was entered. Please try again.");
                }
            }
        }
        static private void Title(string sTitle)
        {
            Console.CursorLeft = (Console.WindowWidth - sTitle.Length) / 2;
            Console.WriteLine(sTitle);
        }
        static private void DrawBackground(CDrawer Canvas)
        {
            int l = 150;
            for (int i = 530; i < 960; i += 50)//drawing the sub lines on the right side
            {
                for (int j = 0; j < 1080; j++)
                {
                    Canvas.SetBBScaledPixel(i, j, Color.FromArgb(255,(l),0,0));
                    
                }
                l -= 12;
            }
            l = 150;
            for (int i = 430; i > 0; i -= 50)//drawing the sub lines on the Left side
            {
                for (int j = 0; j < 1080; j++)
                {
                    Canvas.SetBBScaledPixel(i, j, Color.FromArgb(255, (l), 0, 0));

                }
                l -= 12;
            }
            l = 150;
            for (int i = 590; i < 1080; i += 50)//drawing the sub lines on the top side
            {
                for (int j = 0; j < 960; j++)
                {
                    Canvas.SetBBScaledPixel(j, i, Color.FromArgb(255, (l), 0, 0));

                }
                l -= 12;
            }
            l = 150;
            for (int i = 490; i > 0; i -= 50)//drawing the sub lines on the bottom side
            {
                for (int j = 0; j < 960; j++)
                {
                    Canvas.SetBBScaledPixel(j, i, Color.FromArgb(255, (l), 0, 0));

                }
                l -= 12;
            }


            //horizontal axis
            for (int k = -1; k < 2; k++)
            {
                for (int i = 0; i < 960; i++)//drawing the horizontal line
                {
                    Canvas.SetBBScaledPixel(i, 540+k, Color.Red);
                }

                for (int i = 530; i < 960; i += 50)//drawing the notches on the right side
                {
                    for (int j = (-10 + 540); j < (10 + 540); j++)
                    {
                        Canvas.SetBBScaledPixel(i + k, j, Color.Red);
                    }
                }


                for (int i = 430; i > 0; i -= 50)//drawing the notches on the Left side
                {
                    for (int j = (-10 + 540); j < (10 + 540); j++)
                    {
                        Canvas.SetBBScaledPixel(i + k, j, Color.Red);
                    }
                }
                // vertical axis
                for (int i = 0; i < 1080; i++)//drawing the vertical line
                {
                    Canvas.SetBBScaledPixel(480 + k, i, Color.Red);
                }

                for (int i = 590; i < 1080; i += 50)//drawing the notches on the top side
                {
                    for (int j = (-10 + 480); j < (10 + 480); j++)
                    {
                        Canvas.SetBBScaledPixel(j, i+k, Color.Red);
                    }
                }
                for (int i = 490; i > 0; i -= 50)//drawing the notches on the bottom side
                {
                    for (int j = (-10 + 480); j < (10 + 480); j++)
                    {
                        Canvas.SetBBScaledPixel(j, i+k, Color.Red);
                    }
                }
            }

            Canvas.Render();
        }
    }
}
