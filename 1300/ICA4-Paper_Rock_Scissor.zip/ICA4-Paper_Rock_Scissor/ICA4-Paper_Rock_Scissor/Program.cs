﻿/*ICA4 Paper Rock Scissors
 * Remar Gabriel Espaldon Bacadon
 * 
 * psuedocode
 * variable declaration
 * declaring the random
 * centering and displaying title
 * prompt user for choices
 * read their input
 * lowercase their input
 * make a switch for all possibilities
 * 3 cases for the user input whether rock, or paper, or scissors and default for invalid input
 * a switch inside of rock, paper, and scissors each
 * 3 cases for computer playing rock, or paper, or scissors
 * display results ex: if user input rock and computer output paper, then user lose
 * prompt for program exit
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICA4_Paper_Rock_Scissor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //variable declaration
            string sTitle = "ICA4-Paper Rock Scissor\n";// the title
            string sChoice = "rock";// where user will input their choice

            Random randRPS = new Random();//makes a random number for randRPS and declares it

            int iPC = 0;// works with rand RPS to make the computers choice

            //Main program body
            Console.CursorLeft = (Console.WindowWidth - sTitle.Length) / 2;//centers the title
            Console.Write(sTitle);//displays the title

            //Prompt user for choice
            Console.Write("Please select your play from the folowwing choices...\n\n");//prompts user
            Console.WriteLine(" Paper");//tells user their choices
            Console.WriteLine(" Rock");//^^same
            Console.WriteLine(" Scissors\n");//^^same
            Console.Write("Your selection: ");//where the user will input

            //Read user input
            sChoice = Console.ReadLine().ToLower();//reads and allows the input
            Console.WriteLine("");//makes space

           //make computer choice for rock paper scissors
            iPC = randRPS.Next(0, 3);//computer randomly chooses between 0 to 2 to determine its choice

            //assigning result for each possibilities of user input vs randRPS.next(0, 3); output
            switch (sChoice)//switch looks for the sChoice for each case then does a thing for each case and a thing for default
            {
                case "rock"://case if user input rock
                    switch (iPC)//another switch for each iPC which is the program's choice
                    {
                        case 1://assigning iPC == 1 to program using paper
                            Console.WriteLine("Computer played paper and you played " + sChoice + ".\n");//tells user what each side chose
                            Console.WriteLine("Paper wraps rock, you lose.");//tells the result according to the ancient rules of rock paper scissors
                            break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;
                        case 2://assigning iPC == 2 to program using scissors
                            Console.WriteLine("Computer played scissors and you played " + sChoice + ".\n");//tells user what each side chose
                            Console.WriteLine("Rock breaks scissors, you win.");//tells the result according to the ancient rules of rock paper scissors
                            break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;
                        default://assigning iPC equal to anything, to program using rock. basically just iPC == 0
                            Console.WriteLine("Computer played rock and you played " + sChoice + ".\n");
                            Console.WriteLine("Rock does nothing with rock, draw.");//tells the result according to the ancient rules of rock paper scissors
                            break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;
                    }
                    break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;
                case "paper"://case if user input paper
                    switch (iPC)//each case needs the 3 switch cases for each choice the computer made
                    {
                        case 1://assigning iPC == 1 to program using paper
                            Console.WriteLine("Computer played paper and you played " + sChoice + ".\n");//tells user what each side chose
                            Console.WriteLine("Paper does nothing with paper, you draw.");//tells the result according to the ancient rules of rock paper scissors
                            break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;
                        case 2://assigning iPC == 2 to program using scissors
                            Console.WriteLine("Computer played scissors and you played " + sChoice + ".\n");//tells user what each side chose
                            Console.WriteLine("Scissors cut paper, you lose.");//tells the result according to the ancient rules of rock paper scissors

                            break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;
                        default://assigning iPC equal to anything, to program using rock. basically just iPC == 0
                            Console.WriteLine("Computer played rock and you played " + sChoice + ".\n");//tells user what each side chose
                            Console.WriteLine("Paper wraps rock, you win.");//tells the result according to the ancient rules of rock paper scissors
                            break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;
                    }
                    break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;
                case "scissors"://case if user input scissors
                    switch (iPC)//each case needs the 3 switch cases for each choice the computer made
                    {
                        case 1://assigning iPC == 1 to program using paper
                            Console.WriteLine("Computer played paper and you played " + sChoice + ".\n");//tells user what each side chose
                            Console.WriteLine("Scissors cut paper, you win.");//tells the result according to the ancient rules of rock paper scissors
                            break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;
                        case 2://assigning iPC == 2 to program using scissors
                            Console.WriteLine("Computer played scissors and you played " + sChoice + ".\n");//tells user what each side chose
                            Console.WriteLine("Scissors does nothing with scissors, draw.");//tells the result according to the ancient rules of rock paper scissors
                            break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;
                        default://assigning iPC equal to anything, to program using rock. basically just iPC == 0
                            Console.WriteLine("Computer played rock and you played " + sChoice + ".\n");//tells user what each side chose
                            Console.WriteLine("Rock breaks scissors, you lose.");//tells the result according to the ancient rules of rock paper scissors
                            break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;
                    }
                    break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;

                default:// for if the user input anything other than rock, or paper, scissors
                    Console.WriteLine("You have entered an invalid word or atleast misspelled it");//tells the user they dun goofed

                    break;//they decided to be fancy and took away the curly brackets replacing it with a : and break;
            }
            /*for(int i = 0; i<10; i++)
            *{
            *    iPC = randRPS.Next(0, 3); // while testing computer never played paper had to test with for loop
            *    Console.Write(iPC);
            *}
            */
            Console.WriteLine("\nPress any key to exit");//prompt user for program exit
            Console.ReadKey();//reads any key to proceed
        }   
    }
}
