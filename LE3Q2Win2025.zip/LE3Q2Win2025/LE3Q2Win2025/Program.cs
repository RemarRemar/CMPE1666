﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDIDrawer;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Net;


namespace LE3Q2Win2025
{
    internal class Program
    {  /*Define the Ball struct here */
        public struct Ball
        {
            public int xPos;
            public int yPos;
            public int diameter;

            public Color color;
        }

        private static Random rand= new Random();
        static void Main(string[] args)
        {
            CDrawer canvas= new CDrawer(800,600);


            /***Write your code here for for input of value n and creation of ballArray*/
            Console.Write("Input the number of balls you want to create: ");
            int.TryParse(Console.ReadLine(), out int n);

            /***Write the code here for call GereateBall() and assigning the created structs
             * to elements of ballArray*/
            Ball[] ballArray = new Ball[n];
            for (int i = 0; i < n; i++)
            {
                ballArray[i] = GenerateBall();
            }

            Console.WriteLine();

            Console.WriteLine("Balls Info)");
            Console.WriteLine("------------");
           
            //Uncomment the code below for displaying the elements of ballArray on the console
            
            for (int count=0; count<ballArray.Length; count++)
            {
                Console.Write($"Ball[{count}]-");
                DisplayBall(ballArray[count]);
            }
            
            //Uncomment the next line for calling RenderAllBalls()
            RenderAllBalls(canvas, ballArray);

            Console.WriteLine();
            Console.WriteLine("Press Any Key To Change Ball Colors");
            Console.ReadKey();


            //Uncomment the next 2 lines for calling the 2 methods
            ChangeColor(ballArray);
            RenderAllBalls(canvas, ballArray);

            Console.WriteLine("Press Any key To Exit Program");
            Console.ReadKey();



        }


        /**Write Your Methods Here **/
        private static void ChangeColor(Ball[] balls)
        {
            for(int i = 0;i < balls.Length; i++)
            {
                if (balls[i].xPos < 400)
                {
                    balls[i].color = Color.Yellow;
                }
                else
                {
                    balls[i].color = Color.Green;
                }
            }
        }
        private static void RenderAllBalls(CDrawer drawer, Ball[] balls)
        {
            drawer.Clear();
            for (int i = 0; i < balls.Length; i++)
            {
                RenderBall(drawer, balls[i]);
            }
            drawer.Render();
        }
        private static void RenderBall(CDrawer drawer, Ball ball)
        {
            drawer.AddCenteredEllipse(ball.xPos, ball.yPos, ball.diameter, ball.diameter, ball.color);
        }
        private static Ball GenerateBall()
        {
            int iXVal = GenerateInt(60, 700);
            int iYVal = GenerateInt(50, 550);
            int iDVal = GenerateInt(50, 100);

            Ball ball = new Ball();
            ball.xPos = iXVal;
            ball.yPos = iYVal;
            ball.diameter = iDVal;
            ball.color = Color.Red;
            return (ball);
        }
        private static void DisplayBall(Ball something)
        {
            Console.WriteLine($"({something.xPos},{something.yPos}),{"size",10}: {something.diameter}");
        }
        private static int GenerateInt(int lowerLimit, int upperLimit)
        {
            int iNewInt = rand.Next(lowerLimit, upperLimit + 1);
            return (iNewInt);
        }

    }
}
